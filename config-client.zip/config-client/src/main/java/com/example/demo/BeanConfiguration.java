package com.example.demo;

//import lombok.Data;
//import lombok.NoArgsConstructor;

//@Data
//@NoArgsConstructor
public class BeanConfiguration {
	private int  minResultados;
	private int maxResultados;		
	private String valorFijo;
	private String valorFuncion;
	
	public  BeanConfiguration(int minResultado,int maxResultado,String valorFijo,String valorFuncion)
	{
		this.minResultados=minResultado;
		this.maxResultados=maxResultado;
		this.valorFijo=valorFijo;
		this.valorFuncion=valorFuncion;
	}

	public int getMinResultados() {
		return minResultados;
	}

	public void setMinResultados(int minResultados) {
		this.minResultados = minResultados;
	}

	public int getMaxResultados() {
		return maxResultados;
	}

	public void setMaxResultados(int maxResultados) {
		this.maxResultados = maxResultados;
	}

	public String getValorFijo() {
		return valorFijo;
	}

	public void setValorFijo(String valorFijo) {
		this.valorFijo = valorFijo;
	}

	public String getValorFuncion() {
		return valorFuncion;
	}

	public void setValorFuncion(String valorFuncion) {
		this.valorFuncion = valorFuncion;
	}
	
	
}
