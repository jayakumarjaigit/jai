package pivotal_tutorial;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

//import com.profesorp.configclient.bean.BeanConfiguration;

@RestController
public class GemfireController {
	
	@Autowired
	PersonRepo personRepository;
	
	@GetMapping("/person")
	public PersonEntity getConfiguracion()
	{
		 PersonEntity person = personRepository.findByName("person1");
		 return person;
	
}

}