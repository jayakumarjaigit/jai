package pivotal_tutorial;
import org.springframework.data.gemfire.repository.query.annotation.Trace;
import org.springframework.data.repository.CrudRepository;

public interface PersonRepo extends CrudRepository<PersonEntity, String> {

    @Trace
    PersonEntity findByName(String name);

    @Trace
    Iterable<PersonEntity> findByAgeGreaterThan(int age);

    @Trace
    Iterable<PersonEntity> findByAgeLessThan(int age);

    @Trace
    Iterable<PersonEntity> findByAgeGreaterThanAndAgeLessThan(int greaterThanAge, int lessThanAge);

}