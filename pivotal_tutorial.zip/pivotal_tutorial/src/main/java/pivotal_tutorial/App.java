package pivotal_tutorial;
import static java.util.Arrays.asList;
import static java.util.stream.StreamSupport.stream;

import java.io.IOException;

import org.apache.geode.cache.client.ClientRegionShortcut;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.gemfire.config.annotation.ClientCacheApplication;
import org.springframework.data.gemfire.config.annotation.EnableEntityDefinedRegions;
import org.springframework.data.gemfire.repository.config.EnableGemfireRepositories;

@SpringBootApplication
@ClientCacheApplication(name = "AccessingDataGemFireApplication", logLevel = "info")
@EnableEntityDefinedRegions(basePackageClasses = PersonEntity.class,
  clientRegionShortcut = ClientRegionShortcut.LOCAL)
@EnableGemfireRepositories
public class App {

    public static void main(String[] args) throws IOException {
        SpringApplication.run(App.class, args);
    }

    @Bean
    ApplicationRunner run(PersonRepo personRepository) {

        return args -> {

            PersonEntity abk = new PersonEntity("person1", 26);
            PersonEntity sumit = new PersonEntity("person2", 25);
            PersonEntity john = new PersonEntity("person3", 34);

            System.out.println("Entering into accessing data from Pivotal GemFire framework");

            asList(abk, sumit, john).forEach(person -> System.out.println("\t" + person));

            System.out.println("Saving Alice, Bob and Carol to Pivotal GemFire...");

            personRepository.save(abk);
            personRepository.save(sumit);
            personRepository.save(john);

            System.out.println("Lookup each person by name...");

            asList(abk.getName(), sumit.getName(), john.getName())
            .forEach(name -> System.out.println("\t" + personRepository.findByName(name)));

          System.out.println("Query adults (over 18):");

          stream(personRepository.findByAgeGreaterThan(18).spliterator(), false)
            .forEach(person -> System.out.println("\t" + person));

          System.out.println("Query teens (less than 30):");

          stream(personRepository.findByAgeLessThan(30).spliterator(), false)
            .forEach(person -> System.out.println("\t" + person));

          System.out.println("Query teens (between 12 and 30):");

          stream(personRepository.findByAgeGreaterThanAndAgeLessThan(12, 30).spliterator(), false)
            .forEach(person -> System.out.println("\t" + person));
        };
    }
}